	<hr>
	Message footer view
</body>
</html>