<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>User2</title>
</head>
<body>
<?php
	foreach($users as $user) echo "User : $user<br>";
?>
</body>
</html>