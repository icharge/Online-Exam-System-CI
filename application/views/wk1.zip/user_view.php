<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>User View</title>
</head>
<body>
<?php
	echo"Your name $name<br>"; echo"email :$email<br>";
?>
</body>
</html>