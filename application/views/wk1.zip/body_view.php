
	Hello world from body_view.php<br>
