<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Hello World</title>
</head>
<body>
	HELLO WORLD from hello_view.php.
</body>
</html>